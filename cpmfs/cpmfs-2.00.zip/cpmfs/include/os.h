

int os_isDir( char *path);
int os_isFile(char *path);


